:- use_module(library(chr)).

:- chr_constraint foo(+int,int-int).


