:- use_module(library(chr)).

:- chr_constraint foo/1.

foo(X) # Id <=> true pragma passive(_) .




