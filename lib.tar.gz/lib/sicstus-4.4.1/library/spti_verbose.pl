/* -*- Mode:Prolog; buffer-read-only:t -*-
  DO NOT EDIT! THIS CODE IS GENERATED
*/
:- module(spti_verbose,[]).
% Dummy, not really a foreign resource
foreign_resource(spti_verbose, []).
